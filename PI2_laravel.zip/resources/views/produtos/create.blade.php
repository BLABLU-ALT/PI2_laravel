<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Produtos</title>
    <style>
        body{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container{
            width: 500px;
            margin: 40px auto;
            background-color: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
        }

        h1{
            text-align: center;
            margin-bottom: 20px;
        }

        label{
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }

        input{
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button{
            margin-top: 20px;
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover{
            background-color: #218838;
        }

        .link{
            display: block;
            text-align: center;
            margin-top: 15px;
            text-decoration: none;
            color: #007bff;
        }

        .erro{
            color: red;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Cadastro de Produtos</h1>

        <form action="/produtos" method="POST">
            @csrf

            <label>Nome:</label>
            <input type="text" name="nome" value="{{ old('nome') }}">
            @error('nome')
                <div class="erro">{{ $message }}</div>
            @enderror

            <label>Categoria:</label>
            <input type="text" name="categoria" value="{{ old('categoria') }}">
            @error('categoria')
                <div class="erro">{{ $message }}</div>
            @enderror

            <label>Marca:</label>
            <input type="text" name="marca" value="{{ old('marca') }}">
            @error('marca')
                <div class="erro">{{ $message }}</div>
            @enderror

            <label>Preço:</label>
            <input type="number" step="0.01" name="preco" value="{{ old('preco') }}">
            @error('preco')
                <div class="erro">{{ $message }}</div>
            @enderror

            <label>Quantidade:</label>
            <input type="number" name="quantidade" value="{{ old('quantidade') }}">
            @error('quantidade')
                <div class="erro">{{ $message }}</div>
            @enderror

            <button type="submit">Cadastrar Produto</button>
        </form>

        <a class="link" href="/produtos">Ver produtos cadastrados</a>
    </div>
</body>
</html>