<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Produtos</title>
    <style>
        body{
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        h1{
            text-align: center;
            margin-bottom: 20px;
        }

        table{
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 10px #ccc;
        }

        th, td{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th{
            background-color: #343a40;
            color: white;
        }

        tr:nth-child(even){
            background-color: #f2f2f2;
        }

        .topo{
            width: 100%;
            text-align: center;
            margin-bottom: 20px;
        }

        .botao{
            display: inline-block;
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .sucesso{
            width: 60%;
            margin: 0 auto 20px auto;
            padding: 10px;
            background-color: #d4edda;
            color: #155724;
            border-radius: 5px;
            text-align: center;
        }
    </style>
</head>
<body>

    <h1>Produtos Cadastrados</h1>

    @if(session('success'))
        <div class="sucesso">
            {{ session('success') }}
        </div>
    @endif

    <div class="topo">
        <a class="botao" href="/produtos/cadastro">Novo Produto</a>
    </div>

    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Categoria</th>
            <th>Marca</th>
            <th>Preço</th>
            <th>Quantidade</th>
        </tr>

        @foreach($produtos as $produto)
            <tr>
                <td>{{ $produto->id }}</td>
                <td>{{ $produto->nome }}</td>
                <td>{{ $produto->categoria }}</td>
                <td>{{ $produto->marca }}</td>
                <td>R$ {{ number_format($produto->preco, 2, ',', '.') }}</td>
                <td>{{ $produto->quantidade }}</td>
            </tr>
        @endforeach
    </table>

</body>
</html>